<?php

/**
 * @file plugins/generic/cheesaControlPanel/CheesaControlPanelPlugin.inc.php
 *
 * CHEESA Control Panel (OJS 3.3)
 * Memperbarui CHEESA Theme, Journal Widgets, Crossmark Button, dan panel ini sendiri langsung dari OJS,
 * tanpa mengunggah ulang plugin. Paket diambil dari manifest bertanda tangan digital (mis. di GitHub).
 *
 * Melihat daftar: Journal Manager & Site Admin. Menjalankan update / rollback: hanya Site Admin
 * (karena mengganti kode di server).
 */

import('lib.pkp.classes.plugins.GenericPlugin');
require_once(__DIR__ . '/classes/CheesaUpdater.inc.php');

class CheesaControlPanelPlugin extends GenericPlugin {

	/** Paket yang dikenal panel (nama folder => kategori & label). */
	const KNOWN = [
		'cheesaNovelty' => ['themes', 'CHEESA Theme'],
		'journalWidgets' => ['generic', 'Journal Portal Widgets'],
		'crossmarkButton' => ['generic', 'Crossmark Button'],
		'cheesaControlPanel' => ['generic', 'CHEESA Control Panel'],
	];

	public function register($category, $path, $mainContextId = null) {
		return parent::register($category, $path, $mainContextId);
	}

	public function getDisplayName() { return 'CHEESA Control Panel'; }

	public function getDescription() {
		return 'Cek dan pasang update CHEESA Theme serta plugin pendukungnya langsung dari OJS (tanpa upload ulang). Paket diverifikasi dengan tanda tangan digital.';
	}

	/* ---------------- updater ---------------- */

	private function updater() {
		$plugins = Core::getBaseDir() . '/plugins';
		$files = rtrim(Config::getVar('files', 'files_dir'), '/\\');
		$key = @file_get_contents(__DIR__ . '/cheesa-public-key.pem');
		$fetch = function ($url) {
			if (!preg_match('#^https://#i', $url)) throw new Exception('Alamat update harus https://');
			// manifest jangan diambil dari cache CDN
			if (preg_match('#\.(json|sig)$#', $url)) $url .= '?t=' . time();
			try {
				$res = Application::get()->getHttpClient()->request('GET', $url, ['timeout' => 60, 'http_errors' => true]);
			} catch (\Throwable $e) {
				throw new Exception('Gagal mengunduh ' . preg_replace('#\?t=\d+$#', '', $url) . ' — ' . $e->getMessage());
			}
			return (string) $res->getBody();
		};
		return new CheesaUpdater($plugins, $plugins . '/.cheesacp', $files . '/cheesaControlPanel/backups', $key, $fetch);
	}

	private function contextId($request) {
		$c = $request->getContext();
		return $c ? (int) $c->getId() : CONTEXT_SITE;
	}

	/** Daftar paket: versi terpasang, versi tersedia, status. */
	private function rows(CheesaUpdater $u, $manifest) {
		$rows = [];
		$names = array_unique(array_merge(array_keys(self::KNOWN), $manifest ? array_keys($manifest['packages']) : []));
		foreach ($names as $name) {
			$pkg = $manifest && isset($manifest['packages'][$name]) ? $manifest['packages'][$name] : null;
			$cat = $pkg ? $pkg['category'] : self::KNOWN[$name][0];
			$installed = $u->installedVersion($cat, $name);
			$available = $pkg ? $pkg['version'] : null;
			if (!$installed && !$available) continue;
			$rows[] = [
				'name' => $name,
				'label' => isset(self::KNOWN[$name]) ? self::KNOWN[$name][1] : $name,
				'category' => $cat,
				'installed' => $installed,
				'available' => $available,
				'released' => $pkg && isset($pkg['released']) ? $pkg['released'] : '',
				'canUpdate' => $available && CheesaUpdater::isNewer($available, $installed),
				'backups' => count($u->backups($name)),
			];
		}
		return $rows;
	}

	/** Catat versi baru di tabel versions OJS + bersihkan cache supaya perubahan langsung terlihat. */
	private function afterInstall($request, $category, $name) {
		try {
			import('lib.pkp.classes.site.VersionCheck');
			$info = VersionCheck::parseVersionXML(Core::getBaseDir() . "/plugins/$category/$name/version.xml");
			if ($info && isset($info['version'])) DAORegistry::getDAO('VersionDAO')->insertVersion($info['version'], true);
		} catch (\Throwable $e) {
			error_log('cheesaControlPanel version: ' . $e->getMessage());
		}
		try {
			$tm = TemplateManager::getManager($request);
			$tm->clearTemplateCache();
			$tm->clearCssCache();
		} catch (\Throwable $e) {}
		if (function_exists('opcache_reset')) @opcache_reset();
	}

	/* ---------------- tampilan pengaturan ---------------- */

	public function getActions($request, $actionArgs) {
		$actions = parent::getActions($request, $actionArgs);
		if (!$this->getEnabled()) return $actions;
		import('lib.pkp.classes.linkAction.request.AjaxModal');
		$router = $request->getRouter();
		array_unshift($actions, new LinkAction('settings',
			new AjaxModal($router->url($request, null, null, 'manage', null, ['verb' => 'panel', 'plugin' => $this->getName(), 'category' => 'generic']), $this->getDisplayName()),
			'Buka Panel', null));
		return $actions;
	}

	public function manage($args, $request) {
		$verb = (string) $request->getUserVar('verb');
		if (!in_array($verb, ['panel', 'saveUrl', 'check', 'update', 'rollback'], true)) return parent::manage($args, $request);

		$cid = $this->contextId($request);
		$isAdmin = Validation::isSiteAdmin();
		$msg = ''; $err = '';

		if ($verb !== 'panel') {
			if (!$request->checkCSRF()) return new JSONMessage(false, 'Sesi kedaluwarsa, muat ulang halaman.');
			if ($verb === 'saveUrl') {
				$url = trim((string) $request->getUserVar('manifestUrl'));
				if ($url !== '' && !preg_match('#^https://\S+/manifest\.json$#i', $url)) $err = 'Alamat harus https:// dan berakhiran /manifest.json';
				else { $this->updateSetting($cid, 'manifestUrl', $url, 'string'); $msg = 'Alamat update disimpan.'; }
			} elseif (!$isAdmin) {
				$err = 'Hanya Site Administrator yang boleh memasang update.';
			}
		}

		$u = $this->updater();
		$url = (string) $this->getSetting($cid, 'manifestUrl');
		$manifest = null;
		if ($url) {
			try { $manifest = $u->fetchManifest($url); }
			catch (\Throwable $e) { $err = $err ?: $e->getMessage(); }
		}

		$name = (string) $request->getUserVar('package');
		if (!$err && $isAdmin && $verb === 'update') {
			if (!$manifest || !isset($manifest['packages'][$name])) $err = 'Paket tidak ditemukan di manifest.';
			else {
				try {
					$pkg = $manifest['packages'][$name];
					$r = $u->install($name, $pkg);
					$this->afterInstall($request, $pkg['category'], $name);
					$msg = (isset(self::KNOWN[$name]) ? self::KNOWN[$name][1] : $name) . ' diperbarui ' . ($r['from'] ?: '(baru)') . ' → ' . $r['to'] . '. Tekan Ctrl+F5 di situs untuk melihat perubahan.';
				} catch (\Throwable $e) { $err = 'Update gagal: ' . $e->getMessage(); }
			}
		} elseif (!$err && $isAdmin && $verb === 'rollback') {
			$cat = $manifest && isset($manifest['packages'][$name]) ? $manifest['packages'][$name]['category'] : (isset(self::KNOWN[$name]) ? self::KNOWN[$name][0] : '');
			if (!$cat) $err = 'Paket tidak dikenal.';
			else {
				try { $v = $u->rollback($cat, $name); $this->afterInstall($request, $cat, $name); $msg = 'Dikembalikan ke versi ' . $v . '.'; }
				catch (\Throwable $e) { $err = 'Rollback gagal: ' . $e->getMessage(); }
			}
		} elseif (!$err && $verb === 'check' && $manifest) {
			$msg = 'Daftar versi diperbarui.';
		}

		$problems = $isAdmin ? $u->preflight('generic') : [];
		$tm = TemplateManager::getManager($request);
		$tm->assign([
			'cpRows' => $this->rows($u, $manifest),
			'cpUrl' => $url,
			'cpMsg' => $msg,
			'cpErr' => $err,
			'cpAdmin' => $isAdmin,
			'cpProblems' => $problems,
			'cpGenerated' => $manifest && isset($manifest['generated']) ? $manifest['generated'] : '',
			'cpAction' => $request->getRouter()->url($request, null, null, 'manage', null, ['plugin' => $this->getName(), 'category' => 'generic']),
		]);
		return new JSONMessage(true, $tm->fetch($this->getTemplateResource('panel.tpl')));
	}
}
